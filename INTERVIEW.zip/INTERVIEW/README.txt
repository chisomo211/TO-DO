ToDo-List
ToDo list is a simple web application to save Your daily tasks in order not to miss anything.

Features
Add new task
Mark task as completed / uncompleted
Delete single task
Delete completed tasks

Technologies used:
HTML
CSS
JavaScript


Run the html file named interview to test the application
